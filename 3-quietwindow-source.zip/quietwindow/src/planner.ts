export type Quiet = {id:string; person:string; label:string; room:string; start:number; end:number};
export type Chore = {id:string; label:string; room:string; duration:number; noisy:boolean; earliest:number; deadline:number};
export type State = {revision:number; quiet:Quiet[]; chores:Chore[]; accepted:Plan|null; history:{at:string;label:string}[]; previous:Plan|null};
export type Slot = {choreId:string;start:number;end:number;reason:string};
export type Plan = {id:string; revision:number;label:string;slots:Slot[];unscheduled:{choreId:string;reason:string}[]};
export const time=(n:number)=>`${String(Math.floor(n/60)).padStart(2,'0')}:${String(n%60).padStart(2,'0')}`;
export const parseTime=(s:string)=>{if(!/^\d{2}:\d{2}$/.test(s))throw Error('Use HH:MM');const [h,m]=s.split(':').map(Number);if(h>23||m>59)throw Error('Invalid time');return h*60+m};
export const initialState=():State=>({revision:0,quiet:[{id:'q1',person:'Maya',label:'Client call',room:'office',start:900,end:960},{id:'q2',person:'Arun',label:'Afternoon rest',room:'bedroom',start:840,end:930},{id:'q3',person:'Leo',label:'Reading time',room:'living',start:990,end:1020}],chores:[{id:'c1',label:'Vacuum living room',room:'living',duration:30,noisy:true,earliest:840,deadline:1080},{id:'c2',label:'Run laundry',room:'utility',duration:45,noisy:true,earliest:840,deadline:1080},{id:'c3',label:'Blend dinner prep',room:'kitchen',duration:15,noisy:true,earliest:960,deadline:1080},{id:'c4',label:'Sort clean clothes',room:'bedroom',duration:20,noisy:false,earliest:840,deadline:1080},{id:'c5',label:'Wipe kitchen surfaces',room:'kitchen',duration:20,noisy:false,earliest:840,deadline:1080},{id:'c6',label:'Take recycling out',room:'utility',duration:15,noisy:false,earliest:840,deadline:1080}],accepted:null,previous:null,history:[]});
// User-declared sound reach, not measured decibels. Bedroom is isolated from utility.
export const reaches:Record<string,string[]>={office:['office'],living:['living','office','bedroom'],utility:['utility','office'],kitchen:['kitchen','living','office'],bedroom:['bedroom']};
export const overlap=(a:number,b:number,c:number,d:number)=>a<d&&c<b;
const validText=(x:unknown,max=120):x is string=>typeof x==='string'&&x.trim().length>0&&x.length<=max;
const validRoom=(x:unknown):x is string=>typeof x==='string'&&Object.hasOwn(reaches,x);
export function validateState(s:State){
 if(!s||!Array.isArray(s.quiet)||!Array.isArray(s.chores)||!Number.isSafeInteger(s.revision)||s.revision<0)throw Error('Invalid household');
 if(s.quiet.length>20||s.chores.length>20)throw Error('Too many items');
 const quietIds=new Set<string>(),choreIds=new Set<string>();
 for(const q of s.quiet){if(!q||!validText(q.id,40)||quietIds.has(q.id)||!validText(q.person,60)||!validText(q.label)||!Number.isInteger(q.start)||!Number.isInteger(q.end)||q.start<0||q.end>1440||q.start>=q.end||!validRoom(q.room))throw Error('Invalid quiet window');quietIds.add(q.id)}
 for(const c of s.chores){if(!c||!validText(c.id,40)||choreIds.has(c.id)||!validText(c.label)||typeof c.noisy!=='boolean'||!Number.isInteger(c.duration)||c.duration<=0||c.duration>180||!Number.isInteger(c.earliest)||!Number.isInteger(c.deadline)||c.earliest<0||c.deadline>1440||c.earliest>=c.deadline||!validRoom(c.room))throw Error('Invalid chore');choreIds.add(c.id)}
}
export function conflict(c:Chore,start:number,s:State):string|null {const end=start+c.duration;for(const q of s.quiet){if((c.noisy?reaches[c.room]:[c.room]).includes(q.room)&&overlap(start,end,q.start,q.end))return `${q.person}'s ${q.label.toLowerCase()} in the ${q.room} (${time(q.start)}-${time(q.end)})`};return null}
export function createPlans(s:State):Plan[]{
 validateState(s);
 const base=[...s.chores].sort((a,b)=>a.deadline-b.deadline||Number(b.noisy)-Number(a.noisy)||a.id.localeCompare(b.id));
 const orders:Chore[][]=[];
 // Small-demo search: compare every ordering for six chores, each using greedy slot placement.
 // This improves coverage but does not prove global optimality across every start-time combination.
 function permute(prefix:Chore[],rest:Chore[]){if(!rest.length){orders.push(prefix);return}for(let i=0;i<rest.length;i++)permute([...prefix,rest[i]],rest.filter((_,j)=>i!==j))}
 if(base.length<=6)permute([],base);else orders.push(base,[...base].reverse());
 return ['early','late'].map(kind=>{
  let best:Plan|null=null,bestScore=Infinity;
  for(const order of orders){const slots:Slot[]=[],unscheduled:Plan['unscheduled']=[];
   for(const c of order){let chosen:number|null=null;const candidates:number[]=[];for(let t=Math.ceil(c.earliest/5)*5;t+c.duration<=c.deadline;t+=5)candidates.push(t);if(kind==='late')candidates.reverse();for(const t of candidates){if(conflict(c,t,s)||slots.some(x=>overlap(t,t+c.duration,x.start,x.end)))continue;chosen=t;break}
    if(chosen===null)unscheduled.push({choreId:c.id,reason:'The bounded ordering search could not place this chore. Different start-time combinations may help; review constraints before deciding.'});
    else slots.push({choreId:c.id,start:chosen,end:chosen+c.duration,reason:c.noisy?'Outside every declared quiet window in rooms this sound reaches.':'Respects room occupancy and other chore times.'});
   }
   const score=unscheduled.length*1000000+slots.reduce((n,x)=>n+(kind==='early'?x.end:-x.start),0);
   if(score<bestScore){bestScore=score;best={id:kind+'-'+s.revision,revision:s.revision,label:kind==='early'?'Finish earlier':'Keep the afternoon open',slots:slots.sort((a,b)=>a.start-b.start),unscheduled}}
  }
  return best!;
 });
}
export function approve(s:State,p:Plan):State{if(p.revision!==s.revision)throw Error('Plan is stale. Generate fresh alternatives.');const trusted=createPlans(s).find(x=>x.id===p.id);if(!trusted)throw Error('Unknown plan');return {...s,revision:s.revision+1,accepted:trusted,history:[{at:new Date().toISOString(),label:'Approved '+trusted.label},...s.history].slice(0,20)}}

export function planDiff(s:State,p:Plan){const prior=s.accepted||s.previous;if(!prior)return {baseline:false,moved:0,newlyPlaced:p.slots.length,unresolved:p.unscheduled.length};let moved=0,newlyPlaced=0;for(const x of p.slots){const old=prior.slots.find(y=>y.choreId===x.choreId);if(!old)newlyPlaced++;else if(old.start!==x.start||old.end!==x.end)moved++}return {baseline:true,moved,newlyPlaced,unresolved:p.unscheduled.length}}
